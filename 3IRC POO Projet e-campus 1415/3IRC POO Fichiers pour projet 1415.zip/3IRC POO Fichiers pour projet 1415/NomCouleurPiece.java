package tools;

import model.Couleur;

/**
 * @author francoise.perrin
 * 
 * 
 */
public  class NomCouleurPiece {
	 NomCouleurPiece(String nom, Couleur couleur) {
		this.nom = nom;
		this.couleur = couleur;
	}
	String nom;
	Couleur couleur;
}